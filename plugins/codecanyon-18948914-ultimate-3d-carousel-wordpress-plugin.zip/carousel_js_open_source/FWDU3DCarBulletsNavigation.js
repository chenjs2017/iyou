/* FWDU3DCarBulletsNavigation */
(function(window) {
	var FWDU3DCarBulletsNavigation = function(data, totalItems, curItemId){
		var self = this;
		var prototype = FWDU3DCarBulletsNavigation.prototype;
	
		self.bulletsNormalColor = data.bulletsNormalColor;
		self.bulletsSelectedColor = data.bulletsSelectedColor;
		self.bulletsNormalRadius = data.bulletsNormalRadius * 2;
		self.bulletsSelectedRadius = data.bulletsSelectedRadius * 2;
		
		this.mainHolder_do;
		
		this.totalItems = totalItems;
		this.curItemId = curItemId;
		this.prevCurItemId = 0;
		this.totalWidth = 0;
		this.totalHeight = Math.max(self.bulletsNormalRadius, self.bulletsSelectedRadius);
		
		this.mouseX = 0;
		this.mouseY = 0;
		this.spaceBetweenBullets = data.spaceBetweenBullets;
		this.bullets_ar;
		
		this.isPressed = false;

		this.isMobile = FWDRLU3DCUtils.isMobile;
		this.hasPointerEvent = FWDRLU3DCUtils.hasPointerEvent;

		// ##########################################//
		/* initialize this */
		// ##########################################//
		this.init = function(){
			self.mainHolder_do = new FWDRLU3DCDisplayObject("div", "absolute", "visible");
			self.addChild(self.mainHolder_do);
			self.setHeight(self.totalHeight);
			self.setWidth(self.totalWidth);
			self.createBullets();
			
		};
		
		this.resize = function(stageWidth){
			self.stageWidth = stageWidth;
		};
		
		this.updateBullets = function(id){
			self.curItemId = id;
			var bullet;
			
			for(var i=0; i<self.totalItems; i++){
				bullet = self.bullets_ar[i];
				if(i == self.curItemId){
					bullet.disable();
					bullet.setSelectedState(true);
				}else{
					bullet.enable();
					bullet.setNormalState(true);
				}
			}
			
			self.prevCurItemId = self.curItemId;
		};
		
		this.createBullets = function(){
			var bullet;
			this.bullets_ar = [];
			self.totalWidth = 0;
			for(var i=0; i<self.totalItems; i++){
				FWDU3DCarBullet.setPrototype();
				bullet = new FWDU3DCarBullet(i, 
						data.bulletsBackgroundNormalColor1, 
						data.bulletsBackgroundNormalColor2,
						data.bulletsBackgroundSelectedColor1, 
						data.bulletsBackgroundSelectedColor2,
						data.bulletsShadow,
						data.bulletsNormalRadius,
						data.bulletsSelectedRadius);
				bullet.addListener(FWDU3DCarBullet.MOUSE_UP, self.bulletMouseUpHanlder);
				self.totalWidth += bullet.w + self.spaceBetweenBullets;
				bullet.setX((bullet.w + self.spaceBetweenBullets) * i);
				bullet.hide();
				self.mainHolder_do.addChild(bullet);
				self.bullets_ar[i] = bullet;
			}
			self.totalWidth -= self.spaceBetweenBullets;
			self.setWidth(self.totalWidth);
			
			self.updateBullets(self.curItemId);
			
			clearTimeout(self.showBulletsId_to);
			self.showBulletsId_to = setTimeout(self.show, 600);
		};
		
		this.bulletMouseUpHanlder = function(e){
			self.dispatchEvent(FWDU3DCarBulletsNavigation.BULLET_CLICK, {id:e.id});
		};
		
		this.hideBullets = function(){
			clearTimeout(self.showBulletsId_to);
			var bullet;
			for(var i=0; i<self.totalItems; i++){
				bullet = self.bullets_ar[i];
				bullet.hide(true);
			}
			clearTimeout(self.hideBulletsId_to);
			self.hideBulletsId_to = setTimeout(self.destroyBullets, 800);
		};
		
		this.destroyBullets = function(){
			clearTimeout(self.showBulletsId_to);
			var bullet;
			for(var i=0; i<self.totalItems; i++){
				bullet = self.bullets_ar[i];
				self.mainHolder_do.removeChild(bullet);
				bullet.destroy();
			}
		};
		
		this.show = function(){
			var bullet;
			var delayRight = .1;
			var delayLeft = self.curItemId/10;
			var bullet = self.bullets_ar[self.curItemId];
			bullet.show(0);
			for(var i=self.curItemId; i<self.totalItems; i++){
				bullet = self.bullets_ar[i];
				bullet.show(delayRight);
				delayRight += .1;
			}
			
			for(var i=0; i<self.totalItems; i++){
				bullet = self.bullets_ar[i];
				bullet.show(delayLeft);
				delayLeft -= .1;
			}
		};
		
		// ##############################//
		/* destroy */
		// ##############################//
		this.destroy = function() {
			clearTimeout(self.showBulletsId_to);
			clearTimeout(self.hideBulletsId_to);
			
			self.main_do.destroy();
			self.main_do = null;
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDU3DCarBulletsNavigation.prototype = null;
		};

		this.init();
	};

	/* set prototype */
	FWDU3DCarBulletsNavigation.setPrototype = function(){
		FWDU3DCarBulletsNavigation.prototype = new FWDRLU3DCDisplayObject("div", "absolute", "visible");
	};

	FWDU3DCarBulletsNavigation.BULLET_CLICK = "bulletClick";

	FWDU3DCarBulletsNavigation.prototype = null;
	window.FWDU3DCarBulletsNavigation = FWDU3DCarBulletsNavigation;
}(window));