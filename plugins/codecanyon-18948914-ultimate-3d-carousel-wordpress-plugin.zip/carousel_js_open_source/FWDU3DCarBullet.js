/* FWDU3DCarBullet */
(function (window){
var FWDU3DCarBullet = function(
		id,
		backgroundNormalColor1, 
		backgroundSelectedColor1,
		backgroundNormalColor2,
		backgroundSelectedColor2,
		bulletsShadow,
		bulletsNormalRadius, 
		bulletsSelectedRadius){
		
		var self = this;
		var prototype = FWDU3DCarBullet.prototype;
		
		self.id = id;
		self.normalWidth = bulletsNormalRadius * 2;
		self.selectedWidth = bulletsSelectedRadius * 2;
		self.totalWidthAndHeight = self.totalHeight = Math.max(self.normalWidth, self.selectedWidth);
		
		
		this.backgroundNormalColor_str1 = backgroundNormalColor1;
		this.backgroundSelectedColor_str1 = backgroundSelectedColor1;
		this.backgroundNormalColor_str2 = backgroundNormalColor2;
		this.backgroundSelectedColor_str2 = backgroundSelectedColor2;
		this.bulletsShadow = bulletsShadow;
		
		self.isShowed_bl = true;
		this.isMobile_bl = FWDRLU3DCUtils.isMobile;
		
		//##########################################//
		/* initialize self */
		//##########################################//
		self.init = function(){
			self.setupMainContainers();
			self.setWidth(self.totalWidthAndHeight);
			self.setHeight(self.totalWidthAndHeight);
			self.setButtonMode(true);
			self.setNormalState();
		};
		
		//##########################################//
		/* setup main containers */
		//##########################################//
		self.setupMainContainers = function(){
			
			self.n_sdo = new FWDU3DCarSimpleDisplayObject("div");
			self.n_sdo.setWidth(self.normalWidth);
			self.n_sdo.setHeight(self.normalWidth);
			self.n_sdo.setBkColor(self.backgroundNormalColor_str1);
			self.n_sdo.setCSSGradient(self.backgroundNormalColor_str1, self.backgroundSelectedColor_str1);
			self.n_sdo.setX(parseInt((self.totalWidthAndHeight - self.normalWidth)/2));
			self.n_sdo.getStyle().boxShadow = self.bulletsShadow;
			self.n_sdo.setY(self.n_sdo.x);
			if(!FWDRLU3DCUtils.isIEAndLessThen9) self.n_sdo.getStyle().borderRadius = "50%";
			self.addChild(self.n_sdo);
			
			self.s_sdo = new FWDU3DCarSimpleDisplayObject("div");	
			self.s_sdo.setWidth(self.selectedWidth);
			self.s_sdo.setHeight(self.selectedWidth);
			self.s_sdo.setCSSGradient(self.backgroundNormalColor_str2, self.backgroundSelectedColor_str2);
			self.s_sdo.setX(parseInt((self.totalWidthAndHeight - self.selectedWidth)/2));
			self.s_sdo.setY(self.s_sdo.x);
			self.s_sdo.setBkColor(self.backgroundSelectedColor_str1);
			if(!FWDRLU3DCUtils.isIEAndLessThen9) self.s_sdo.getStyle().borderRadius = "50%";
			self.addChild(self.s_sdo);
			
			self.setWidth(self.totalWidth);
			self.setHeight(self.totalHeight);
			self.screen.style.yellowOverlayPointerEvents = "none";
			
			if(self.isMobile_bl){
				if(self.hasPointerEvent_bl){
					self.screen.addEventListener("pointerup", self.onMouseUp);
					self.screen.addEventListener("pointerover", self.onMouseOver);
					self.screen.addEventListener("pointerout", self.onMouseOut);
				}else{
					self.screen.addEventListener("touchend", self.onMouseUp);
				}
			}else if(self.screen.addEventListener){	
				self.screen.addEventListener("mouseover", self.onMouseOver);
				self.screen.addEventListener("mouseout", self.onMouseOut);
				self.screen.addEventListener("mouseup", self.onMouseUp);
			}else if(self.screen.attachEvent){
				self.screen.attachEvent("onmouseover", self.onMouseOver);
				self.screen.attachEvent("onmouseout", self.onMouseOut);
				self.screen.attachEvent("onmouseup", self.onMouseUp);
			}
		};
		
		self.onMouseOver = function(e){
			self.dispatchEvent(FWDU3DCarBullet.SHOW_TOOLTIP, {e:e});
			if(self.isDisabledForGood_bl) return;
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE || e.pointerType == "mouse"){
				if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
				self.dispatchEvent(FWDU3DCarBullet.MOUSE_OVER, {e:e});
				self.setSelectedState();
			}
		};
			
		self.onMouseOut = function(e){
			if(self.isDisabledForGood_bl) return;
			if(!e.pointerType || e.pointerType == e.MSPOINTER_TYPE_MOUSE || e.pointerType == "mouse"){
				if(self.isDisabled_bl || self.isSelectedFinal_bl) return;
				self.dispatchEvent(FWDU3DCarBullet.MOUSE_OUT, {e:e});
				self.setNormalState();
			}
		};
		
		self.onMouseUp = function(e){
			if(self.isDisabledForGood_bl) return;
			if(e.preventDefault) e.preventDefault();
			if(self.isDisabled_bl || e.button == 2) return;
			self.dispatchEvent(FWDU3DCarBullet.MOUSE_UP, {id:self.id});
		};
		
		//##############################//
		// set select / deselect final.
		//##############################//
		self.setSelected = function(){
			self.isSelectedFinal_bl = true;
			if(!self.s_sdo) return;
			FWDU3DCarModTweenMax.killTweensOf(self.s_sdo);
			FWDU3DCarModTweenMax.to(self.s_sdo, .8, {alpha:1, ease:Expo.easeOut});
		};
		
		self.setUnselected = function(){
			self.isSelectedFinal_bl = false;
			if(!self.s_sdo) return;
			FWDU3DCarModTweenMax.to(self.s_sdo, .8, {alpha:0, delay:.1, ease:Expo.easeOut});
		};
		
		//####################################//
		/* Set normal / selected state */
		//####################################//
		this.setNormalState = function(){
			if(!self.s_sdo) return;
			FWDU3DCarModTweenMax.killTweensOf(self.s_sdo);
			FWDU3DCarModTweenMax.to(self.s_sdo, .5, {alpha:0, ease:Expo.easeOut});	
		};
		
		this.setSelectedState = function(){
			if(!self.s_sdo) return;
			FWDU3DCarModTweenMax.killTweensOf(self.s_sdo);
			FWDU3DCarModTweenMax.to(self.s_sdo, .5, {alpha:1, delay:.1, ease:Expo.easeOut});
		};
		
		//####################################//
		/* Disable / enable */
		//####################################//
		this.setDisabledState = function(){
			if(self.isSetToDisabledState_bl) return;
			self.isSetToDisabledState_bl = true;
			if(self.d_sdo) self.d_sdo.setX(0);
		};
		
		this.setEnabledState = function(){
			if(!self.isSetToDisabledState_bl) return;
			self.isSetToDisabledState_bl = false;
			if(self.d_sdo) self.d_sdo.setX(-100);
		};
		
		this.disable = function(setNormalState){
			if(self.isDisabledForGood_bl  || self.isDisabled_bl) return;
			self.isDisabled_bl = true;
			self.setButtonMode(false);
			//FWDU3DCarModTweenMax.to(self, .6, {alpha:.4});
			if(!setNormalState) self.setNormalState();
		};
		
		this.enable = function(){
			if(self.isDisabledForGood_bl || !self.isDisabled_bl) return;
			self.isDisabled_bl = false;
			self.setButtonMode(true);
			//FWDU3DCarModTweenMax.to(self, .6, {alpha:1});
		};
		
		this.disableForGood = function(){
			self.isDisabledForGood_bl = true;
			self.setButtonMode(false);
		};
		
		this.showDisabledState = function(){
			if(self.d_sdo.x != 0) self.d_sdo.setX(0);
		};
		
		this.hideDisabledState = function(){
			if(self.d_sdo.x != -100) self.d_sdo.setX(-100);
		};
		
		//#####################################//
		/* show / hide */
		//#####################################//
		this.show = function(dl){
			if(self.isShowed_bl) return;
			self.isShowed_bl = true;
			
			
			FWDU3DCarModTweenMax.killTweensOf(self);
			if(!FWDRLU3DCUtils.isIEAndLessThen9){
				self.setAlpha(0);
				FWDU3DCarModTweenMax.to(self, .8, {alpha:1, delay:dl,  onStart:function(){self.setVisible(true);}, ease:Expo.easeOut});
			}else if(FWDRLU3DCUtils.isIEAndLessThen9){
				self.setVisible(true);
			}
		};	
			
		this.hide = function(animate){
			if(!self.isShowed_bl) return;
			self.isShowed_bl = false;
			FWDU3DCarModTweenMax.killTweensOf(self);
			FWDU3DCarModTweenMax.killTweensOf(self.n_sdo);
			
			if(animate){
				if(!FWDRLU3DCUtils.isIEAndLessThen9){
					FWDU3DCarModTweenMax.to(self, .8, {alpha:0, ease:Expo.easeOut});
				}else if(FWDRLU3DCUtils.isIEAndLessThen9){
					self.setVisible(false);
				}
			}else{
				self.setVisible(false);
			}
		};
		
		this.destroy = function(){
			FWDU3DCarModTweenMax.killTweensOf(self.n_sdo);
			FWDU3DCarModTweenMax.killTweensOf(self);
			
			self.setInnerHTML("");
			prototype.destroy();
			self = null;
			prototype = null;
			FWDU3DCarBullet.prototype = null;
		};
		
		self.init();
	};
	
	/* set prototype */
	FWDU3DCarBullet.setPrototype = function(hasTransform){
		FWDU3DCarBullet.prototype = null;
		if(hasTransform){
			FWDU3DCarBullet.prototype = new FWDRLS3DTransformDisplayObject("div", "absolute", "visible");
		}else{
			FWDU3DCarBullet.prototype = new FWDRLU3DCDisplayObject("div", "absolute", "visible");
		}
	};
	
	FWDU3DCarBullet.CLICK = "onClick";
	FWDU3DCarBullet.MOUSE_OVER = "onMouseOver";
	FWDU3DCarBullet.SHOW_TOOLTIP = "showTooltip";
	FWDU3DCarBullet.MOUSE_OUT = "onMouseOut";
	FWDU3DCarBullet.MOUSE_UP = "onMouseDown";
	
	FWDU3DCarBullet.prototype = null;
	window.FWDU3DCarBullet = FWDU3DCarBullet;
}(window));