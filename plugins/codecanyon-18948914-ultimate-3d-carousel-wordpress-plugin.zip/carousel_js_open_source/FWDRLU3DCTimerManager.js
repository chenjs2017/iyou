/* Slide show time manager */
(function(window){
	
	var FWDRLU3DCTimerManager = function(delay){
		
		var self = this;
		var prototpype = FWDRLU3DCTimerManager.prototype;
		
		this.timeOutId;
		this.delay = delay;
		this.isStopped_bl = true;
		
		self.stop = function(){
			if(self.isStopped_bl) return;
			self.pause();
			self.isStopped_bl = true;
			self.dispatchEvent(FWDRLU3DCTimerManager.STOP);
		};
		
		self.start = function(){
			if(!self.isStopped_bl) return;
			self.isStopped_bl = false;
			
			self.timeOutId = setTimeout(self.onTimeHanlder, self.delay);
			self.dispatchEvent(FWDRLU3DCTimerManager.START);
		};
		
		self.pause = function(){
			if(self.isStopped_bl) return;
			clearTimeout(self.timeOutId);
			self.dispatchEvent(FWDRLU3DCTimerManager.PAUSE);
		};
		
		self.resume = function(){
			if(self.isStopped_bl) return;
			clearTimeout(self.timeOutId);
			self.timeOutId = setTimeout(self.onTimeHanlder, self.delay);
			self.dispatchEvent(FWDRLU3DCTimerManager.RESUME);
		};
		
		self.onTimeHanlder = function(){
			self.dispatchEvent(FWDRLU3DCTimerManager.TIME);
		};
	};

	FWDRLU3DCTimerManager.setProtptype = function(){
		FWDRLU3DCTimerManager.prototype = new FWDRLU3DCEventDispatcher();
	};
	
	FWDRLU3DCTimerManager.START = "start";
	FWDRLU3DCTimerManager.STOP = "stop";
	FWDRLU3DCTimerManager.RESUME = "resume";
	FWDRLU3DCTimerManager.PAUSE = "pause";
	FWDRLU3DCTimerManager.TIME = "time";
	
	FWDRLU3DCTimerManager.prototype = null;
	window.FWDRLU3DCTimerManager = FWDRLU3DCTimerManager;
	
}(window));